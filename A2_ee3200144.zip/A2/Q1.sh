#!/bin/bash

python3 "$(dirname "$0")/Q1/Q1.py" "$1" "$2"